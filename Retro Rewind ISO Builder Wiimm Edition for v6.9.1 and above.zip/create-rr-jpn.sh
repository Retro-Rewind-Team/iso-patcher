#!/bin/sh
# (c) 2013-09-25, by Wiimm

#------------------------------------------------------------------------------
# settings

SRC_ID=RMCJ01
SRC_TYPE=JPN

DEST_ID=RMCJTO
DEST_NAME="Mario Kart Retro Rewind"

IMAGE_TYPE=wbfs
eval $( tr -d '\r'< ./_image_type.bat | awk '{print $2}' )

#------------------------------------------------------------------------------
# job

rm -rf workdir.tmp
wit extract . --DEST workdir.tmp --psel data --links --include $SRC_ID -vv1 -F-.svn/ || exit 1
[[ -d workdir.tmp ]] || exit 1

mkdir -p "workdir.tmp/files/Binaries"
mkdir -p "workdir.tmp/files/Experts"
ren "RetroRewind6/Language/SPA(EU)" "SPAEU"
ren "RetroRewind6/Language/SPA(NTSC)" "SPANTSC"
mkdir -p "workdir.tmp/files/Binaries"
mkdir -p "workdir.tmp/files/Ghosts"
mkdir -p "workdir.tmp/files/Ghosts/ExpertsRT"
mkdir -p "workdir.tmp/files/Ghosts/ExpertsCT"
mkdir -p "workdir.tmp/files/Jcene"
mkdir -p "workdir.tmp/files/Fcene"
mkdir -p "workdir.tmp/files/Gcene"
mkdir -p "workdir.tmp/files/Dcene"
mkdir -p "workdir.tmp/files/Ucene"
mkdir -p "workdir.tmp/files/Ecene"
mkdir -p "workdir.tmp/files/Ncene"
mkdir -p "workdir.tmp/files/Icene"
mkdir -p "workdir.tmp/files/Kcene"
mkdir -p "workdir.tmp/files/Acene"
mkdir -p "workdir.tmp/files/Tcene"
mkdir -p "workdir.tmp/files/Ccene"
mkdir -p "workdir.tmp/files/Jcene/UI"
mkdir -p "workdir.tmp/files/Fcene/UI"
mkdir -p "workdir.tmp/files/Gcene/UI"
mkdir -p "workdir.tmp/files/Dcene/UI"
mkdir -p "workdir.tmp/files/Ucene/UI"
mkdir -p "workdir.tmp/files/Ecene/UI"
mkdir -p "workdir.tmp/files/Ncene/UI"
mkdir -p "workdir.tmp/files/Icene/UI"
mkdir -p "workdir.tmp/files/Kcene/UI"
mkdir -p "workdir.tmp/files/Acene/UI"
mkdir -p "workdir.tmp/files/Tcene/UI"
mkdir -p "workdir.tmp/files/Ccene/UI"
mkdir -p "workdir.tmp/files/Jace"
mkdir -p "workdir.tmp/files/Face"
mkdir -p "workdir.tmp/files/Gace"
mkdir -p "workdir.tmp/files/Dace"
mkdir -p "workdir.tmp/files/Uace"
mkdir -p "workdir.tmp/files/Eace"
mkdir -p "workdir.tmp/files/Nace"
mkdir -p "workdir.tmp/files/Iace"
mkdir -p "workdir.tmp/files/Kace"
mkdir -p "workdir.tmp/files/Aace"
mkdir -p "workdir.tmp/files/Tace"
mkdir -p "workdir.tmp/files/Cace"
. ./copy-files.sh

wit copy workdir.tmp -T0 --DEST new-image/%X  -ovv --links \
	--id "$DEST_ID" --ticket-id=RMCR --tmd-id=RMCR --boot-id=RMCJ --name "$DEST_NAME" --$IMAGE_TYPE
ren "RetroRewind6/Language/SPAEU" "SPA(EU)"
ren "RetroRewind6/Language/SPANTSC" "SPA(NTSC)"


